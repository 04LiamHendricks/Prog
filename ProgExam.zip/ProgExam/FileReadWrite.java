import java.io.*;
import java.util.Scanner;
public class FileReadWrite {
    public static void writeToFile(String fileName,String content) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            System.out.println("Reading from file:");
            while ((line = reader.readLine()) !=null){
                System.out.println(line);
            }
        }catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
    }
    public static void readFromFile(String fileName){
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))){
            String line;
            System.out.println("Reader from file:");
            while ((line = reader.readLine()) != null){
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
    }
    public static void main (String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        // Input file name
        System.out.println("Enter file name:");
        String fileName = scanner.nextLine();

        //Input content to write to the file
        System.out.println("Enter content to write to the file:");
        String content = scanner.nextLine();

        //write content to file
        writeToFile(fileName,content);

        //Read content from file
        readFromFile(fileName);
        scanner.close();
    }
}