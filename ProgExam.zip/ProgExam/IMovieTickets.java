public interface IMovieTickets {
    // Method to calculate total movie sales for a given movie
    int TotalMovieSales(int[] movieTicketSales);

    // Method to determine the top-performing movie based on total sales
    String TopMovie(String[] movies, int[] totalSales);
}
