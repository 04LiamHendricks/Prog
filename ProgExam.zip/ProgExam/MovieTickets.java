public class MovieTickets implements IMovieTickets {

    // Method to calculate total sales for a movie across the months
    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        // Sum up all sales for the given movie
        for (int sales : movieTicketSales) {
            total += sales;
        }
        return total;
    }

    // Method to determine the top movie based on the total sales
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int maxSales = 0;
        String topMovie = "";

        // Loop through the total sales array and find the movie with the highest sales
        for (int i = 0; i < totalSales.length; i++) {
            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i];
                topMovie = movies[i];
            }
        }

        return topMovie;
    }

    // Method to generate and print the movie sales report
    public void generateSalesReport(String[] movies, int[][] ticketSales) {
        int[] totalSales = new int[movies.length];

        // Calculate total sales for each movie
        for (int i = 0; i < ticketSales.length; i++) {
            totalSales[i] = TotalMovieSales(ticketSales[i]);
        }

        // Print the sales report for each movie
        System.out.println("Movie Ticket Sales Report for January, February, and March 2024");
        System.out.println("-------------------------------------------------------------");

        // Loop through the movies and print sales for each month
        for (int i = 0; i < movies.length; i++) {
            System.out.print(movies[i] + ": ");
            for (int j = 0; j < ticketSales[i].length; j++) {
                System.out.print("Month " + (j + 1) + ": " + ticketSales[i][j] + " tickets ");
                if (j < ticketSales[i].length - 1) {
                    System.out.print("| ");
                }
            }
            System.out.println(" | Total Sales: " + totalSales[i] + " tickets");
        }

        // Get and display the top-performing movie
        String topMovie = TopMovie(movies, totalSales);
        System.out.println("Top Performing Movie: " + topMovie);
    }
}
