import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

    class MovieTicketsTest {

        private MovieTickets movieTickets;

        @BeforeEach
        void setUp() {
            movieTickets = new MovieTickets(); // Initialize the MovieTickets object before each test
        }

        // Test the TotalMovieSales() method
        @Test
        void testTotalMovieSales() {
            // Sample sales for Movie A
            int[] movieASales = {3500, 1200, 1600};

            // Calculate the total sales using the method
            int totalSales = movieTickets.TotalMovieSales(movieASales);

            // Assert that the total sales are correct
            assertEquals(6300, totalSales, "Total sales for Movie A should be 6300");
        }

        // Test the TopMovie() method
        @Test
        void testTopMovie() {
            // Movies and their total sales
            String[] movies = {"Napoleon", "Oppenheimer"};
            int[] totalSales = {6200, 6300};  // Total sales for Movie A and Movie B

            // Get the top-performing movie
            String topMovie = movieTickets.TopMovie(movies, totalSales);

            // Assert that the top movie is "Movie A" since it has the higher sales
            assertEquals("Napoleon", topMovie, "The top-performing movie should be Movie A");
        }

        // Test when all movies have the same sales
        @Test
        void testTopMovieWithEqualSales() {
            // Movies and equal total sales
            String[] movies = {"Napoleon", "Oppenheimer"};
            int[] totalSales = {6200, 6300};  // Same sales for both movies

            // Get the top-performing movie (should return the first one since they're equal)
            String topMovie = movieTickets.TopMovie(movies, totalSales);

            // Assert that the top movie is "Movie A" (it should return the first one with equal sales)
            assertEquals("Napoleon", topMovie, "When sales are equal, the first movie should be returned as the top-performing movie");
        }

        // Test when there are no sales data (edge case)
        @Test
        void testTotalMovieSalesWithNoSales() {
            // Empty sales data
            int[] noSales = {};

            // Calculate the total sales (should be 0)
            int totalSales = movieTickets.TotalMovieSales(noSales);

            // Assert that the total sales are 0
            assertEquals(0, totalSales, "Total sales for no data should be 0");
        }

        // Test edge case where there are no movies
        @Test
        void testTopMovieWithNoMovies() {
            // No movies and no sales
            String[] emptyMovies = {};
            int[] emptySales = {};

            // Get the top-performing movie (should return an empty string or throw an exception)
            Exception exception = assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
                movieTickets.TopMovie(emptyMovies, emptySales);
            });

            // Assert that an ArrayIndexOutOfBoundsException is thrown
            assertNotNull(exception, "Exception should be thrown for empty movie and sales data");
        }
    }
