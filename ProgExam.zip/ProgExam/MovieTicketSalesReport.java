public class MovieTicketSalesReport {

    public static void main(String[] args) {
        // 2D Array where:
        // Row 1 -> Movie A
        // Row 2 -> Movie B
        // Columns -> January, February, March
        int[][] ticketSales = {
                {3000, 1500, 1700}, // Sales for Movie A in Jan, Feb, Mar
                {3500, 1200, 1600}  // Sales for Movie B in Jan, Feb, Mar
        };

        // Movie names corresponding to rows in the ticketSales array
        String[] movies = {"Napoleon", "Oppenheimer"};

        // Generate the movie sales report
        generateSalesReport(ticketSales, movies);
    }

    // Method to generate the movie sales report
    public static void generateSalesReport(int[][] ticketSales, String[] movies) {
        // Array for month names
        String[] months = {"January", "February", "March"};

        // Print the header for the report
        System.out.println("Movie Ticket Sales Report for January, February, and March 2024");
        System.out.println("-------------------------------------------------------------");

        // Loop through the movies and their sales data
        for (int i = 0; i < ticketSales.length; i++) {
            int totalSales = 0;
            System.out.print(movies[i] + ": ");

            // Loop through the months and display the sales for each month
            for (int j = 0; j < ticketSales[i].length; j++) {
                System.out.print(months[j] + ": " + ticketSales[i][j] + " tickets ");

                // Add the sales of each month to the total
                totalSales += ticketSales[i][j];

                // Print a separator after each month, except the last one
                if (j < ticketSales[i].length - 1) {
                    System.out.print("| ");
                }
            }
            // After listing sales for all months, print the total sales
            System.out.println(" | Total Sales: " + totalSales + " tickets");
            System.out.println(); // Blank line for separation between movies
        }
    }
}
