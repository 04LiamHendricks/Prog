public class MovieSalesApp {

    public static void main(String[] args) {
        // Movie names
        String[] movies = {"Napoleon", "Oppenheimer"};

        // Data for the ticket sales (rows: Movies, columns: months)
        int[][] ticketSales = {
                {3000, 1500, 1700}, // Sales for Movie A in Jan, Feb, Mar
                {3500, 1200, 1600}  // Sales for Movie B in Jan, Feb, Mar
        };

        // Create an instance of MovieTickets
        MovieTickets movieTickets = new MovieTickets();

        // Generate and display the sales report
        movieTickets.generateSalesReport(movies, ticketSales);
    }
}
