import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class MovieTicketSalesApp {

    private JFrame frame;
    private JComboBox<String> movieComboBox;
    private JTextField ticketsField, priceField;
    private JTextArea salesReportArea;
    private MovieTickets movieTickets;

    // Movie Data
    private static final String[] MOVIES = {"Napoleon", "Oppenheimer", "Damsel"};
    private static final double[] TICKET_PRICES = {150.00, 200.00, 250.00};

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MovieTicketSalesApp window = new MovieTicketSalesApp();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public MovieTicketSalesApp() {
        movieTickets = new MovieTickets();

        frame = new JFrame("Movie Ticket Sales");
        frame.setBounds(100, 100, 500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new GridLayout(8, 2, 10, 10));

        JMenuBar menuBar = new JMenuBar();
        frame.setJMenuBar(menuBar);

        // File Menu with Exit option
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        fileMenu.add(exitMenuItem);
        menuBar.add(fileMenu);
        exitMenuItem.addActionListener(e -> System.exit(0));

        // Tools Menu with Process and Clear options
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processMenuItem = new JMenuItem("Process");
        JMenuItem clearMenuItem = new JMenuItem("Clear");
        toolsMenu.add(processMenuItem);
        toolsMenu.add(clearMenuItem);
        menuBar.add(toolsMenu);

        // Movie selection combo box
        JLabel movieLabel = new JLabel("Select Movie:");
        frame.getContentPane().add(movieLabel);

        movieComboBox = new JComboBox<>(MOVIES);
        frame.getContentPane().add(movieComboBox);

        // Number of tickets input
        JLabel ticketsLabel = new JLabel("Number of Tickets:");
        frame.getContentPane().add(ticketsLabel);

        ticketsField = new JTextField();
        frame.getContentPane().add(ticketsField);
        ticketsField.setColumns(10);

        // Price per ticket input
        JLabel priceLabel = new JLabel("Price per Ticket:");
        frame.getContentPane().add(priceLabel);

        priceField = new JTextField();
        priceField.setEditable(false); // Read-only
        frame.getContentPane().add(priceField);
        priceField.setColumns(10);

        // Sales report display area
        JLabel reportLabel = new JLabel("Sales Report:");
        frame.getContentPane().add(reportLabel);

        salesReportArea = new JTextArea();
        salesReportArea.setEditable(false);
        salesReportArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        salesReportArea.setBackground(Color.LIGHT_GRAY);
        JScrollPane scrollPane = new JScrollPane(salesReportArea);
        frame.getContentPane().add(scrollPane);

        // Set initial price for the selected movie
        updatePriceField();

        // Process menu item action listener
        processMenuItem.addActionListener(e -> processSales());

        // Clear menu item action listener
        clearMenuItem.addActionListener(e -> clearFields());

        // Movie selection action listener
        movieComboBox.addActionListener(e -> updatePriceField());
    }

    private void updatePriceField() {
        int selectedIndex = movieComboBox.getSelectedIndex();
        priceField.setText(String.format("$%.2f", TICKET_PRICES[selectedIndex]));
    }

    private void processSales() {
        String selectedMovie = (String) movieComboBox.getSelectedItem();
        String ticketsText = ticketsField.getText();
        String priceText = priceField.getText();

        try {
            int numberOfTickets = Integer.parseInt(ticketsText);
            double ticketPrice = Double.parseDouble(priceText.replace("$", "").trim());

            MovieTicketData movieTicketData = new MovieTicketData(selectedMovie, numberOfTickets, ticketPrice);

            // Validate input data
            if (!movieTickets.ValidateData(movieTicketData)) {
                JOptionPane.showMessageDialog(frame, "Invalid input data. Please check all fields.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double totalSales = movieTickets.calculateTotalTicketPrice(numberOfTickets, ticketPrice);
            double vatAmount = totalSales * 0.15;
            double totalAmount = totalSales + vatAmount;

            String report = String.format("Movie: %s\n", selectedMovie);
            report += String.format("Number of Tickets: %d\n", numberOfTickets);
            report += String.format("Price per Ticket: $%.2f\n", ticketPrice);
            report += String.format("Total Sales: $%.2f\n", totalSales);
            report += String.format("VAT (15%%): $%.2f\n", vatAmount);
            report += String.format("Total Amount (with VAT): $%.2f\n", totalAmount);

            salesReportArea.setText(report);

            saveReportToFile(report);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Please enter valid numeric values for tickets and price.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        ticketsField.setText("");
        salesReportArea.setText("");
        movieComboBox.setSelectedIndex(0);
        updatePriceField();
    }

    private void saveReportToFile(String report) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
            writer.write(report);
            JOptionPane.showMessageDialog(frame, "Sales report saved to report.txt", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error saving the report to file.", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
