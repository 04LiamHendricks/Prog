public class MovieTickets implements IMovieTickets {

    @Override
    public double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        return numberOfTickets * ticketPrice;
    }

    @Override
    public boolean ValidateData(MovieTicketData movieTicketData) {
        // Validate movie name
        if (movieTicketData.getMovieName() == null || movieTicketData.getMovieName().isEmpty()) {
            return false; // Movie name cannot be empty
        }

        // Validate ticket price
        if (movieTicketData.getTicketPrice() <= 0) {
            return false; // Ticket price must be greater than zero
        }

        // Validate number of tickets
        if (movieTicketData.getNumberOfTickets() <= 0) {
            return false; // Number of tickets must be greater than zero
        }

        return true;
    }
}
