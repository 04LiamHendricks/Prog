import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MovieTicketsTest {

    MovieTickets movieTickets = new MovieTickets();

    @Test
    void testCalculateTotalTicketPrice() {
        double total = movieTickets.calculateTotalTicketPrice(5, 15.0);
        assertEquals(75.0, total, "The total ticket price should be 75.00");
    }

    @Test
    void testValidateDataValid() {
        MovieTicketData validData = new MovieTicketData("Napoleon", 5, 15.0);
        boolean isValid = movieTickets.ValidateData(validData);
        assertTrue(isValid, "Valid data should return true");
    }

    @Test
    void testValidateDataInvalidMovieName() {
        MovieTicketData invalidData = new MovieTicketData("", 5, 15.0);
        boolean isValid = movieTickets.ValidateData(invalidData);
        assertFalse(isValid, "Empty movie name should return false");
    }

    @Test
    void testValidateDataInvalidNumberOfTickets() {
        MovieTicketData invalidData = new MovieTicketData("Napoleon", 0, 15.0);
        boolean isValid = movieTickets.ValidateData(invalidData);
        assertFalse(isValid, "Number of tickets should be greater than zero");
    }

    @Test
    void testValidateDataInvalidTicketPrice() {
        MovieTicketData invalidData = new MovieTicketData("Napoleon", 5, 0.0);
        boolean isValid = movieTickets.ValidateData(invalidData);
        assertFalse(isValid, "Ticket price should be greater than zero");
    }
}

